package testRunner;

import io.cucumber.java.Before;
import io.cucumber.testng.AbstractTestNGCucumberTests;
import io.cucumber.testng.CucumberOptions;
import org.openqa.selenium.WebDriver;
import org.testng.Reporter;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.BeforeSuite;
import org.testng.annotations.BeforeTest;
import util.driverFactory;

@CucumberOptions(
        features = {"src/test/java/features"},
        glue={"stepDefinitions","util"},
        tags = "@searchAndBasketOperations",
        plugin = {
                "summary","pretty","html:Reports/CucumberReport/Reports.html",
                "json:Reports/CucumberReport/Report",
                "com.aventstack.extentreports.cucumber.adapter.ExtentCucumberAdapter:"
        }
)
public class runner extends AbstractTestNGCucumberTests {

        WebDriver driver;
        @BeforeMethod
        public void before(){
                String browser= Reporter.getCurrentTestResult().getTestContext().getCurrentXmlTest().getParameter("browser");
                driver= driverFactory.Intialize_Driver(browser);
                System.out.println("HGET");

        }
}
