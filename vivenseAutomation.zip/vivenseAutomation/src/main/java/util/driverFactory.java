package util;

import io.github.bonigarcia.wdm.WebDriverManager;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.chrome.ChromeOptions;
import org.openqa.selenium.firefox.FirefoxDriver;

import java.util.concurrent.TimeUnit;

public class driverFactory {

    static WebDriver driver;

    public  static WebDriver Intialize_Driver(String browser){
        ChromeOptions options = new ChromeOptions(); // Disable Chrome notifications
        options.addArguments("--disable-notifications");// Disable Chrome notifications
        System.setProperty("webdriver.chrome.driver", "./lib/chromedriver"); // Disable Chrome notifications
                                                                             //driver içne options

        if(browser.equals("Chrome")){
            WebDriverManager.chromedriver().setup();
            driver=new ChromeDriver(options);
        }
        else if (browser.equals("Firefox"))
        {
            WebDriverManager.firefoxdriver().setup();
            driver=new FirefoxDriver();
        }
        else
        {
            WebDriverManager.chromedriver().setup();
            driver=new ChromeDriver(options);
        }






        driver.get("https://www.vivense.com/");
        driver.manage().window().maximize();
        driver.manage().timeouts().pageLoadTimeout(10, TimeUnit.SECONDS);
        driver.manage().timeouts().implicitlyWait(10,TimeUnit.SECONDS);
        return getDriver();
    }

    public  static synchronized WebDriver getDriver(){return driver;}

}
