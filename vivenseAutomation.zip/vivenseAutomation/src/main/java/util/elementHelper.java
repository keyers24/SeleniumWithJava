package util;

import org.openqa.selenium.*;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.Assert;

import java.util.List;

public class elementHelper {

    WebDriver driver;
    WebDriverWait wait;

    Actions actions;
    public elementHelper(WebDriver driver){
        this.driver=driver;
        this.wait=new WebDriverWait(driver,10);
        this.actions=new Actions(driver);
    }

    public WebElement checkElement(By key){

        return  wait.until(ExpectedConditions.presenceOfElementLocated(key));
    }
    public  void click(By key){
        WebElement element= checkElement(key);
        element.click();

    }
    public void clickElementWithText(By key,String text){
        boolean find=false;
        List<WebElement> elements =wait.until(ExpectedConditions.presenceOfAllElementsLocatedBy(key)); //findElements(key);
        for (WebElement element : elements)
        {
            if (element.getText().contains(text)){
                element.click();
                find=true;
                break;
            }
        }
        Assert.assertEquals(true,find);
    }
    public  void senKeyElement(By key, String text){
        WebElement element=checkElement(key);
        element.sendKeys(text);
    }
    public void keyTheKeypad(By key, Keys keyboard){
        checkElement(key).sendKeys(keyboard);
    }

   /* public WebElement findElement(By key){
        WebElement element = checkElement(key);
        scrollToElement(element);
        return  element;
    }*/

    /*public  void scrollToElement(WebElement element){
        String scrollElementIntoMiddle= "var viewportHeight= Math.max(document.documentElement.clientHeight, window.innerHeight || 0);*"
                + "var elementTop = arguments[0].getBoundingClientRect().top;"
                + "window.scrollBy(0,elementTop-(viewPortHeight/2));";
        ((JavascriptExecutor) driver).executeScript(scrollElementIntoMiddle, element);
    }*/


    public void scrollToElement(WebElement element) {

        JavascriptExecutor jse = (JavascriptExecutor) driver;
        jse.executeScript("arguments[0].scrollIntoView();",element);
    }
    /*
    scroll to element
    WebElement element = driver.findElement(By.id("id_of_element"));
    ((JavascriptExecutor) driver).executeScript("arguments[0].scrollIntoView(true);", element);
    Thread.sleep(500);
*/
}
