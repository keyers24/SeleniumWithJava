package pages;


import org.openqa.selenium.*;
import util.elementHelper;

import static org.openqa.selenium.Keys.ENTER;

public class searchAndBasketOperationsPage {

    By searchBox = By.cssSelector("input#search-suggestion");

    By submitSearchButton = By.cssSelector(".main_header_search_btn");
    By productName= By.xpath("//h3[.='Madrid Koltuk Takımı, Bora Koyu Gri']");

    By addCart=By.cssSelector(".add-to-cart-btn");


    By cancel = By.cssSelector(".remove_from_cart-fake");

    By verifyPop = By.cssSelector("a#delete-id");

    By verifyPage = By.cssSelector(".empty-cart-container > h4");
    WebDriver driver ;
    elementHelper helper;
    public searchAndBasketOperationsPage(WebDriver driver){
        this.driver=driver;
        helper=new elementHelper(driver);
    }

    public void searchToWord(String word){
        helper.senKeyElement(searchBox,word);
        helper.click(submitSearchButton);

    }


    public  void clickProduct() throws InterruptedException {
        WebElement element = driver.findElement(productName);
        ((JavascriptExecutor) driver).executeScript("arguments[0].scrollIntoView(true);", element);
        helper.click(productName);

    }

    public  void  addCardAndCancel(){
        helper.click(addCart);
        helper.click(cancel);
        helper.click(verifyPop);
        helper.checkElement(verifyPage);
    }



}
