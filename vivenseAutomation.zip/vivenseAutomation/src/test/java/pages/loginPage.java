package pages;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.support.ui.WebDriverWait;
import util.elementHelper;

import static org.openqa.selenium.Keys.F5;

public class loginPage {
    By logo = By.cssSelector("a[class='vivense_logo_wrapper'] img[alt='Vivense Logo']");
    By girisYapButton= By.xpath("//div[@class='shortcut_column membership_wrapper_notlogin headerLoginRegister']//span[@class='shortcut_icon signup_icon']");
    By girisButton=By.xpath("//a[.='GİRİŞ']");

    By inputUsername=By.id("loginEmail");
    By inputPassword=By.id("loginPassword");

    By submit= By.cssSelector(".user-register-button");
    By checkLogin= By.xpath("//span[.='Hesabım']");

    By checkTryFailLogin= By.cssSelector(".generalErrorMessage");

    WebDriver driver;
    WebDriverWait wait;
    elementHelper helper;
    public  loginPage(WebDriver driver){
        this.driver=driver;
        this.helper=new elementHelper(driver);
    }

    public  void navigateVivense(){
        helper.checkElement(logo);
    }
    public  void login(String username,String pass)
    {
        helper.click(girisYapButton);
        helper.click(girisButton);
        helper.senKeyElement(inputUsername,username);
        helper.senKeyElement(inputPassword,pass);
        helper.click(submit);

    }

    public void checkSuccessfulLogin(){
        helper.checkElement(checkLogin);
       // driver.close();
        driver.quit();
    }
    public  void setCheckTryFailLogin(){
        helper.checkElement(checkTryFailLogin);
       // driver.close();
        driver.quit();
    }

}
