package stepDefinitions;

import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;
import pages.searchAndBasketOperationsPage;
import util.driverFactory;

public class searchAndBasketOperationsStep {

    searchAndBasketOperationsPage search = new searchAndBasketOperationsPage(driverFactory.getDriver());

    @Given("Search for {string} from search bar")
    public void searchForFromSearchBar(String word) {
        search.searchToWord(word);
    }

    @When("Click on the relevant {string}")
    public void clickOnTheRelevant(String productName) throws InterruptedException {
        search.clickProduct();
    }

    @Then("Check added to cart")
    public void checkAddedToCart() {
        search.addCardAndCancel();
    }
}
