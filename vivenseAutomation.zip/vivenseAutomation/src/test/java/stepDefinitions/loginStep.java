package stepDefinitions;

import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;
import pages.loginPage;
import util.driverFactory;

public class loginStep {

    loginPage loginPage=new loginPage(driverFactory.getDriver());

    @Given("navigate vivense")
    public  void navigateVivense(){
        loginPage.navigateVivense();
    }

    @When("login with {string} and {string}")
    public void loginWithAnd(String username, String passowrd) {
        loginPage.login(username,passowrd);
    }

    @Then("check successful login")
    public void checkSuccessfulLogin() {
        loginPage.checkSuccessfulLogin();
    }

    @Then("check try fail login")
    public void checkTryFailLogin() {
        loginPage.setCheckTryFailLogin();
    }
}
